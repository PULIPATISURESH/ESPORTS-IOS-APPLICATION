<?php
error_reporting(0);

require_once('db.php');

$response = [];
$username = $_POST['username'];
$mobilenumber = $_POST['mobilenumber'];
$email = $_POST['email'];
$password = $_POST['password'];

if (empty($username) || empty($mobilenumber) || empty($email) || empty($password)) {
    $response['status'] = false;
    $response['message'] = 'All fields are required.';
} else {
    $emailExist = mysqli_query($dbconn, "SELECT * FROM sign WHERE email = '$email'");

    if (mysqli_num_rows($emailExist) == 0) {
        $insertData = "INSERT INTO sign (username, mobilenumber, email, password) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($dbconn, $insertData);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'ssss', $username, $mobilenumber, $email, $password);
            if (mysqli_stmt_execute($stmt)) {
                $id = mysqli_insert_id($dbconn);
                $response['status'] = true;
                $response['message'] = 'Registered successfully';
                $response['UserId'] = $id;
            } else {
                $response['status'] = false;
                $response['message'] = 'Registration failed: ' . mysqli_error($dbconn);
            }
            mysqli_stmt_close($stmt);
        } else {
            $response['status'] = false;
            $response['message'] = 'Database error: ' . mysqli_error($dbconn);
        }
    } else {
        $response['status'] = false;
        $response['message'] = 'Email already exists.';
    }
}

header('Content-Type: application/json; charset=UTF-8');
echo json_encode($response);
?>
