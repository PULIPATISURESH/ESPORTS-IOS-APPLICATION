import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
     
        let delayInSeconds: TimeInterval = 1.5
        DispatchQueue.main.asyncAfter(deadline: .now() + delayInSeconds) {
            // Code to be executed after 2 seconds
            let webVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
            self.navigationController?.pushViewController(webVc, animated: true)
        }
    }
}
