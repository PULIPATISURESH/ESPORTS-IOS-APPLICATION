import UIKit

class ForgotVC: UIViewController {

    @IBOutlet weak var savepassword: UIButton!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var newpasswordTF: UITextField!
    @IBOutlet weak var confirmpasswordTF: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        self.navigationController?.isNavigationBarHidden = true
    }

    @IBAction func savepassword(_ sender: Any) {
        if usernameTF.text == "" || emailTF.text == "" || newpasswordTF.text == "" || confirmpasswordTF.text == "" {
            showAlert(title: "Warning", message: "Please fill in all fields.")
        } else {
            registerUser()
        }
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    func registerUser() {
        let formData: [String: String] = [
            "username": usernameTF.text ?? "",
            "email": emailTF.text ?? "",
            "newpassword": newpasswordTF.text ?? "",
            "confirmpassword": confirmpasswordTF.text ?? ""
        ]
        APIHandler().postAPIValues(type: ForgotModel.self, apiUrl: Constants.serviceType.forgotUrl.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    if response.status == true {
                        self.showAlert(title: "Success", message: "Password reset successful!")
                        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                        self.navigationController?.pushViewController(nextVC, animated: true)
                    } else {
                        self.showAlert(title: "Error", message: response.message)
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
                self.showAlert(title: "Error", message: "An error occurred during password reset.")
            }
        }
    }
}
