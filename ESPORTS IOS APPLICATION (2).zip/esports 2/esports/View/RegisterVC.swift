import UIKit

class RegisterVC: UIViewController {

    @IBOutlet weak var already: UILabel!
    @IBOutlet weak var registerlogin: UIButton!
    @IBOutlet weak var back: UIImageView!

    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var mobileTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true

        back.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
        already.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }
    }

    @IBAction func registerlogin(_ sender: Any) {
        if userNameTF.text == "" || emailTF.text == "" || mobileTF.text == "" || passwordTF.text == "" {
            showAlert(title: "Warning", message: "Please fill in all fields.")
        } else if !isValidMobileNumber(mobileTF.text ?? "") {
                    showAlert(title: "Warning", message: "Invalid mobile number format. Please enter a 10-digit number.")
                } else if !isValidEmail(emailTF.text ?? "") {
                    showAlert(title: "Warning", message: "Invalid email address format. Please enter a valid email.")
                } else {
            registerUser()
        }
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }

    func registerUser() {
        let formData: [String: String] = [
            "username": userNameTF.text ?? "",
            "mobilenumber": mobileTF.text ?? "",
            "email": emailTF.text ?? "",
            "password": passwordTF.text ?? ""
        ]
        APIHandler().postAPIValues(type: SignUpJson.self, apiUrl: Constants.serviceType.signUpUrl.rawValue, method: "POST", formData: formData) { result in
            switch result {
            case .success(let response):
                print("Status: \(response.status)")
                print("Message: \(response.message)")
                DispatchQueue.main.async {
                    if response.status == "success" {
                        self.showAlert(title: "Success", message: "Registration successful!")
                        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
                        self.navigationController?.pushViewController(nextVC, animated: true)
                    } else {
                        self.showAlert(title: "Error", message: response.message)
                    }
                }
            case .failure(let error):
                print("Error: \(error)")
                self.showAlert(title: "Error", message: "An error occurred during registration.")
            }
        }
    }
    // Validate mobile number with a 10-digit pattern
        func isValidMobileNumber(_ mobileNumber: String) -> Bool {
            let mobilePattern = #"^\d{10}$"#
            return NSPredicate(format: "SELF MATCHES %@", mobilePattern).evaluate(with: mobileNumber)
        }

        // Validate email address with a basic pattern
        func isValidEmail(_ email: String) -> Bool {
            let emailPattern = #"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"#
            return NSPredicate(format: "SELF MATCHES %@", emailPattern).evaluate(with: email)
        }
    }
