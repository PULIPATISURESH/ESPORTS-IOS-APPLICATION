//
//  HomeViewController.swift
//  esports
//
//  Created by SAIL on 21/09/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var backtohome: UIImageView!
    @IBOutlet weak var profile: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
        backtohome.addAction(for: .tap) {
            self.navigationController?.popViewController(animated: true)
        }

    }
    

    @IBAction func liveAction(_ sender: Any) {
        let webVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WebVc") as! WebVc
        self.navigationController?.pushViewController(webVc, animated: true)
        
        
    }
    
    @IBAction func profile(_ sender: Any) {
        let webVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        self.navigationController?.pushViewController(webVc, animated: true)
        
    }
    
}
