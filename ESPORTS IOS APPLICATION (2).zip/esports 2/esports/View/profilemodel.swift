import Foundation

// MARK: - Welcome
struct ProfileJSON: Codable {
    let status: Bool
    let message: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let userid, email, mobilenumber, password: String
    let username: String
}
